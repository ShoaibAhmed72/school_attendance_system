import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class Main {

    public static void main(String[] args) {
        JFrame frame = new JFrame("School Attendance System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);

        ImageIcon logo = new ImageIcon(new ImageIcon("sas_logo.png").getImage().getScaledInstance(400, 400, Image.SCALE_SMOOTH));
        frame.setIconImage(logo.getImage());

        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception e) {
            e.printStackTrace();
        }

        JTabbedPane tabbedPane = new JTabbedPane();
        JPanel loginPanel = createLoginPanelWithSignup(frame, tabbedPane);

        frame.getContentPane().add(loginPanel);
        frame.setVisible(true);
    }

    public static JPanel createLoginPanelWithSignup(JFrame frame, JTabbedPane tabbedPane) {
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(new Color(255, 230, 235));

        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        card.setBackground(Color.WHITE);
        card.setPreferredSize(new Dimension(400, 400));
        card.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel titleLabel = new JLabel("Login to Your Account");
        titleLabel.setFont(new Font("Arial Black", Font.BOLD, 24));
        titleLabel.setForeground(new Color(50, 50, 50));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        

        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(new Font("SansSerif", Font.BOLD, 16)); // <-- Bold added here
        

        JTextField usernameField = new JTextField(15);
        stylizeField(usernameField);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(new Font("SansSerif", Font.BOLD, 16)); // <-- Bold added here
        JPasswordField passwordField = new JPasswordField(15);
        stylizeField(passwordField);

        JLabel roleLabel = new JLabel("Account Type:");
        roleLabel.setFont(new Font("SansSerif", Font.BOLD, 16)); // <-- Bold added here
        JComboBox<String> roleComboBox = new JComboBox<>(new String[]{"Admin", "Teacher", "Student"});
        roleComboBox.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        roleComboBox.setFont(new Font("SansSerif", Font.PLAIN, 16));

        JButton loginButton = new JButton("Login");
        JButton signupButton = new JButton("Sign Up");

        stylizeButton(loginButton, new Color(70, 130, 180));
        stylizeButton(signupButton, new Color(100, 149, 237));

        card.add(titleLabel);
        card.add(Box.createVerticalStrut(30));
        card.add(userLabel);
        card.add(usernameField);
        card.add(Box.createVerticalStrut(15));
        card.add(passLabel);
        card.add(passwordField);
        card.add(Box.createVerticalStrut(15));
        card.add(roleLabel);
        card.add(roleComboBox);
        card.add(Box.createVerticalStrut(30));
        card.add(loginButton);
        card.add(Box.createVerticalStrut(10));
        card.add(signupButton);

        mainPanel.add(card);

        loginButton.addActionListener(e -> {
            String selectedRole = (String) roleComboBox.getSelectedItem();
            String role = authenticate(usernameField.getText(), passwordField.getPassword(), selectedRole);
            if (role != null) {
                showTabsByRole(role, frame, tabbedPane);
            } else {
                JOptionPane.showMessageDialog(frame, "Invalid login or role mismatch");
            }
        });

        signupButton.addActionListener(e -> {
            showSignupDialog(frame);
        });

        return mainPanel;
    }

    private static void stylizeField(JTextField field) {
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        field.setFont(new Font("SansSerif", Font.PLAIN, 16));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
    }

    private static void stylizeButton(JButton button, Color color) {
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("SansSerif", Font.BOLD, 16));
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
    }

    public static void showSignupDialog(JFrame frame) {
        JTextField newUsername = new JTextField();
        JPasswordField newPassword = new JPasswordField();
        JComboBox<String> accountTypeComboBox = new JComboBox<>(new String[]{"Admin", "Teacher", "Student"});

        Object[] fields = {
                "New Username:", newUsername,
                "New Password:", newPassword,
                "Account Type:", accountTypeComboBox
        };

        int option = JOptionPane.showConfirmDialog(frame, fields, "Sign Up", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String username = newUsername.getText();
            String password = new String(newPassword.getPassword());
            String accountType = (String) accountTypeComboBox.getSelectedItem();

            if (signup(username, password, accountType)) {
                JOptionPane.showMessageDialog(frame, "Account created successfully!\nYou can now login.");
            } else {
                JOptionPane.showMessageDialog(frame, "Error creating account.");
            }
        }
    }

    public static boolean signup(String username, String password, String accountType) {
        try (Connection conn = DBConnection.getConnection()) {
            if (conn == null) {
                JOptionPane.showMessageDialog(null, "Database connection failed!");
                return false;
            }

            String query = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.setString(3, accountType);

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error occurred while creating account: " + e.getMessage());
            return false;
        }
    }

    public static String authenticate(String username, char[] password, String selectedRole) {
        String role = null;
        try (Connection conn = DBConnection.getConnection()) {
            if (conn == null) {
                JOptionPane.showMessageDialog(null, "Database connection failed!");
                return null;
            }

            String query = "SELECT role FROM users WHERE username = ? AND password = ? AND role = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, new String(password));
            stmt.setString(3, selectedRole);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                role = rs.getString("role");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return role;
    }

   public static void showTabsByRole(String role, JFrame frame, JTabbedPane tabbedPane) {
    tabbedPane.removeAll();

    // Add appropriate tabs based on the role
    if (role.equals("Admin")) {
        JPanel adminPanel = new JPanel(new BorderLayout());
        adminPanel.add(new StudentPanel(), BorderLayout.CENTER);
        tabbedPane.add("Student Management", adminPanel);

        JPanel classSchedulePanel = new JPanel(new BorderLayout());
        classSchedulePanel.add(new ClassSchedulePanel(), BorderLayout.CENTER);
        tabbedPane.add("Class Schedule", classSchedulePanel);

        JPanel attendancePanel = new JPanel(new BorderLayout());
        attendancePanel.add(new AttendancePanel(), BorderLayout.CENTER);
        tabbedPane.add("Attendance", attendancePanel);

        JPanel reportsPanel = new JPanel(new BorderLayout());
        reportsPanel.add(new ReportsPanel(), BorderLayout.CENTER);
        tabbedPane.add("Reports", reportsPanel);
    } else if (role.equals("Teacher")) {
        JPanel attendancePanel = new JPanel(new BorderLayout());
        attendancePanel.add(new AttendancePanel(), BorderLayout.CENTER);
        tabbedPane.add("Attendance", attendancePanel);

        JPanel reportsPanel = new JPanel(new BorderLayout());
        reportsPanel.add(new ReportsPanel(), BorderLayout.CENTER);
        tabbedPane.add("Reports", reportsPanel);
    } else if (role.equals("Student")) {
        JPanel reportsPanel = new JPanel(new BorderLayout());
        reportsPanel.add(new ReportsPanel(), BorderLayout.CENTER);
        tabbedPane.add("Reports", reportsPanel);
    }

    // Create logout button
    JButton logoutButton = new JButton("Logout");
    logoutButton.setFocusable(false);
    logoutButton.setBackground(new Color(220, 53, 69));
    logoutButton.setForeground(Color.WHITE);
    logoutButton.setFont(new Font("SansSerif", Font.BOLD, 14));
    logoutButton.addActionListener(e -> {
        JPanel loginPanel = createLoginPanelWithSignup(frame, tabbedPane);
        frame.setContentPane(loginPanel);
        frame.revalidate();
        frame.repaint();
    });

    // Bottom panel with logout button
    JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    bottomPanel.add(logoutButton);

    // Wrap tabbedPane and bottomPanel into one panel
    JPanel mainPanel = new JPanel(new BorderLayout());
    mainPanel.add(tabbedPane, BorderLayout.CENTER);
    mainPanel.add(bottomPanel, BorderLayout.SOUTH);

    frame.setContentPane(mainPanel);
    frame.revalidate();
    frame.repaint();
}

}
