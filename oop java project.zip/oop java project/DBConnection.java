import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    // Database credentials
    private static final String URL = "jdbc:mysql://localhost:3306/school_attendance_system"; // Your DB URL
    private static final String USER = "root";  // Your MySQL username
    private static final String PASSWORD = "root";  // Your MySQL password

    // Method to establish a connection to the database
    public static Connection getConnection() {
        try {
            // Load and register MySQL JDBC driver (optional with newer JDBC versions)
            System.out.println("Attempting to load MySQL JDBC Driver...");
            Class.forName("com.mysql.cj.jdbc.Driver");

            System.out.println("Driver loaded successfully.");

            // Create and return a connection to the database
            System.out.println("Attempting to connect to the database...");
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);

            System.out.println("Connection established successfully.");
            return conn;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("MySQL JDBC Driver not found.");
            return null;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Connection to the database failed.");
            return null;
        }
    }
}
