import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AttendancePanel extends JPanel {
    private JComboBox<String> classDropdown;
    private JTable studentTable;
    private DefaultTableModel studentTableModel;
    private JButton loadButton, submitButton;
    private JSpinner dateSpinner;

    public AttendancePanel() {
        setLayout(new BorderLayout());

         setBackground(new Color(240, 248, 255)); // Light background

        Font font = new Font("Segoe UI", Font.PLAIN, 14);

        JPanel topPanel = new JPanel(new FlowLayout());

          topPanel.setBackground(new Color(240, 248, 255));

        classDropdown = new JComboBox<>();
        loadClasses();

        loadButton = new JButton("Load Students");
        submitButton = new JButton("Submit Attendance");

        // Date Picker
        dateSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "yyyy-MM-dd");
        dateSpinner.setEditor(dateEditor);
        dateSpinner.setValue(new Date()); // Set current date as default

        topPanel.add(new JLabel("Select Class:"));
        topPanel.add(classDropdown);
        topPanel.add(new JLabel("Select Date:"));
        topPanel.add(dateSpinner);
        topPanel.add(loadButton);
        topPanel.add(submitButton);

        studentTableModel = new DefaultTableModel(new Object[]{"Roll Number", "Student Name", "Present"}, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 2) return Boolean.class; // Checkbox column
                return String.class;
            }
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 2; // Only checkbox editable
            }
        };

        studentTable = new JTable(studentTableModel);
        JScrollPane scrollPane = new JScrollPane(studentTable);

        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        loadButton.addActionListener(e -> loadStudents());
        submitButton.addActionListener(e -> submitAttendance());
    }

    private void loadClasses() {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT DISTINCT class_name FROM students";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                classDropdown.addItem(rs.getString("class_name"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading classes: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadStudents() {
        String selectedClass = (String) classDropdown.getSelectedItem();
        if (selectedClass == null) {
            JOptionPane.showMessageDialog(this, "Please select a class first!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT roll_number, name FROM students WHERE class_name = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, selectedClass);
            ResultSet rs = stmt.executeQuery();

            studentTableModel.setRowCount(0);

            while (rs.next()) {
                String rollNumber = rs.getString("roll_number");
                String studentName = rs.getString("name");
                studentTableModel.addRow(new Object[]{rollNumber, studentName, Boolean.FALSE});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading students: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void submitAttendance() {
        String selectedClass = (String) classDropdown.getSelectedItem();
        Date selectedDate = (Date) dateSpinner.getValue();
        String dateStr = new SimpleDateFormat("yyyy-MM-dd").format(selectedDate);

        if (selectedClass == null || studentTableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No students to mark attendance.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            for (int i = 0; i < studentTableModel.getRowCount(); i++) {
                String rollNumber = (String) studentTableModel.getValueAt(i, 0);
                Boolean isPresent = (Boolean) studentTableModel.getValueAt(i, 2);

                String status = (isPresent != null && isPresent) ? "Present" : "Absent";

                // Check if already attendance marked
                String checkQuery = "SELECT * FROM attendance WHERE class_name = ? AND roll_number = ? AND attendance_date = ?";
                PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
                checkStmt.setString(1, selectedClass);
                checkStmt.setString(2, rollNumber);
                checkStmt.setString(3, dateStr);
                ResultSet rs = checkStmt.executeQuery();

                if (rs.next()) {
                    // Update existing
                    String updateQuery = "UPDATE attendance SET status = ? WHERE class_name = ? AND roll_number = ? AND attendance_date = ?";
                    PreparedStatement updateStmt = conn.prepareStatement(updateQuery);
                    updateStmt.setString(1, status);
                    updateStmt.setString(2, selectedClass);
                    updateStmt.setString(3, rollNumber);
                    updateStmt.setString(4, dateStr);
                    updateStmt.executeUpdate();
                } else {
                    // Insert new
                    String insertQuery = "INSERT INTO attendance (class_name, roll_number, attendance_date, status) VALUES (?, ?, ?, ?)";
                    PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
                    insertStmt.setString(1, selectedClass);
                    insertStmt.setString(2, rollNumber);
                    insertStmt.setString(3, dateStr);
                    insertStmt.setString(4, status);
                    insertStmt.executeUpdate();
                }
            }

            JOptionPane.showMessageDialog(this, "Attendance submitted successfully!");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error submitting attendance: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
