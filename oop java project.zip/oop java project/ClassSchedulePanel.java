import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ClassSchedulePanel extends JPanel {
    private JTable scheduleTable;
    private DefaultTableModel scheduleTableModel;
    private JTextField classField, subjectField, timeField;

    public ClassSchedulePanel() {
        setLayout(new BorderLayout());

        // Top input panel
        JPanel topPanel = new JPanel(new GridBagLayout());
        topPanel.setBackground(new Color(240, 248, 255));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        JLabel classLabel = new JLabel("Class Name:");
        classField = new JTextField(15);

        JLabel subjectLabel = new JLabel("Subject:");
        subjectField = new JTextField(15);

        JLabel timeLabel = new JLabel("Time:");
        timeField = new JTextField(10);

        JButton addButton = new JButton("Add Schedule");
        JButton viewButton = new JButton("View Schedules");

        gbc.gridx = 0; gbc.gridy = 0; topPanel.add(classLabel, gbc);
        gbc.gridx = 1; topPanel.add(classField, gbc);

        gbc.gridx = 0; gbc.gridy = 1; topPanel.add(subjectLabel, gbc);
        gbc.gridx = 1; topPanel.add(subjectField, gbc);

        gbc.gridx = 0; gbc.gridy = 2; topPanel.add(timeLabel, gbc);
        gbc.gridx = 1; topPanel.add(timeField, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        topPanel.add(addButton, gbc);
        gbc.gridx = 1;
        topPanel.add(viewButton, gbc);

        // Table setup
        scheduleTableModel = new DefaultTableModel(new String[]{"Class Name", "Subject", "Time"}, 0);
        scheduleTable = new JTable(scheduleTableModel);
        JScrollPane scrollPane = new JScrollPane(scheduleTable);

        // Add components to main panel
        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        // Button actions
        addButton.addActionListener(e -> {
            String className = classField.getText().trim();
            String subject = subjectField.getText().trim();
            String time = timeField.getText().trim();

            if (className.isEmpty() || subject.isEmpty() || time.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields!", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            addClassSchedule(className, subject, time);
            classField.setText("");
            subjectField.setText("");
            timeField.setText("");
        });

        viewButton.addActionListener(e -> viewClassSchedules());
    }

    private void addClassSchedule(String className, String subject, String time) {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "INSERT INTO class_schedule (class_name, subject, schedule_time) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, className);
            stmt.setString(2, subject);
            stmt.setString(3, time);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Class schedule added successfully!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error adding schedule: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewClassSchedules() {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT * FROM class_schedule";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            scheduleTableModel.setRowCount(0); // clear old rows
            while (rs.next()) {
                String className = rs.getString("class_name");
                String subject = rs.getString("subject");
                String time = rs.getString("schedule_time");
                scheduleTableModel.addRow(new Object[]{className, subject, time});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading schedules: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
